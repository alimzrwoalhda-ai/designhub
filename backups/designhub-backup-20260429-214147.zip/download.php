<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM designs WHERE id = ? AND status = 'approved'");
$stmt->execute([$id]);
$design = $stmt->fetch();

if (!$design || !is_file($design['design_file'])) {
    http_response_code(404);
    exit('الملف غير موجود.');
}

$pdo->prepare('UPDATE designs SET downloads = downloads + 1 WHERE id = ?')->execute([$id]);
$pdo->prepare('INSERT INTO downloads (user_id, design_id) VALUES (?, ?)')->execute([current_user()['id'] ?? null, $id]);

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($design['design_file']) . '"');
header('Content-Length: ' . filesize($design['design_file']));
readfile($design['design_file']);
exit;
