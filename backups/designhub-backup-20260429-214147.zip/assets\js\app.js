const root = document.documentElement;
const savedTheme = localStorage.getItem('designhub-theme') || 'light';
root.dataset.theme = savedTheme;

document.getElementById('themeToggle')?.addEventListener('click', () => {
    const nextTheme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    root.dataset.theme = nextTheme;
    localStorage.setItem('designhub-theme', nextTheme);
});

document.querySelectorAll('[data-confirm]').forEach((button) => {
    button.addEventListener('click', (event) => {
        if (!confirm(button.dataset.confirm || 'هل أنت متأكد؟')) {
            event.preventDefault();
        }
    });
});
