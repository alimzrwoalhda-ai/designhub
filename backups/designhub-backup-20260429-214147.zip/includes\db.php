<?php
declare(strict_types=1);

$dbHost = '127.0.0.1';
$dbName = 'designhub_arabic';
$dbUser = 'root';
$dbPass = '';

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    exit('تعذر الاتصال بقاعدة البيانات. تأكد من تشغيل MySQL واستيراد ملف database.sql.');
}
